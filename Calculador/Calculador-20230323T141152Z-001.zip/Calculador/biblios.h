#ifndef FUNCAO_H_INCLUDED
#define FUNCAO_H_INCLUDED

int  hall(); 
int CONTINUAR();
int  CALCULAINI();
int BUSCA();
int ESCOLHA();
int ARQUIVOLIMPO(int teste);
double adicao( double X2,double Y2,int R1);
double multiplicacao(double X1,double Y1,int R1);
double divisao(double  X3,double Y3,int R1);
double pontecia(double X4,double Y4,int R1);
double porcentagem(double X5,double Y5,int R1);
double raiz(double X6,int R1);
double subtrai(double X,double Y,int R1);
void HISTORICO();
void HISTORICOGERAL();
void PORTUGUES();
void ABREARQUIV();
void FECHAARQUIV();
void SAVEARQUIV();
void LIMPAARQUIV();
void APAGANDO();
void COMOUSAR();
void  REPETIDO();



#endif
