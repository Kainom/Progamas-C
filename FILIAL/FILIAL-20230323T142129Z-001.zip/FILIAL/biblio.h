#ifndef FUNCAO_H_INCLUDED
#define FUNCAO_H_INCLUDED


void PORTUGUES();
void ABREARQUIV();
void FECHAARQUIV();
void SALVA();
void vendas();
void MEDIA_TOTAL();
void HISTORICO();
void LIMPAARQUIV();
void especificando();
void FILIAL_NOME(char fili[20],int cod);
int CONTINUA();
int HALL();
int BUSCA();
int VAZIO();
int testafilial(char F[1]);
int testavendas(char teste[50]);
int teste_nome(char nombre1[50]);
int HISTORICO_ESCOLHA();
float MAIS_LUCRO(int *K,float *Menorlucro,int *filimenor);
float  maioridade();
float  minoridade();


















#endif
